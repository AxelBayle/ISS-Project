package cjc.madrid.watree;

import android.content.Context;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;


public class DisplaySettingsActivity extends AppCompatActivity {

    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

    String url = "http://watreeserveur.ddns.net/~/in-cse/in-name/Watree/";
    private static final String ORIGIN_HEADER = "X-M2M-Origin";
    private static final String CT_HEADER = "Content-type";
    private static final String ACCEPT = "accept";
    private static final String XML = "application/xml";
    private static final String JSON = "application/json";

    Map<String, String> plants = new HashMap<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_settings_activity);
        StrictMode.setThreadPolicy(policy);

        plants.put("Orchid","55");
        plants.put("Kalanchoe","80");
        plants.put("Oxalis","70");
        plants.put("Cactus","20");
        plants.put("Dracaena Marginata", "50");
        plants.put("Citrus","60");
        plants.put("Jasmine","55");
        plants.put("Without plant","0");
    }



    public void setData(View view) throws Exception{
        //send data
        Spinner plant1 = (Spinner) findViewById(R.id.spinner_plant_1);
        Spinner plant2 = (Spinner) findViewById(R.id.spinner_plant_2);
        Spinner plant3 = (Spinner) findViewById(R.id.spinner_plant_3);

        JSONObject jsonObject1 = createJSONObject("1", plants.get(plant1.getSelectedItem().toString()));
        JSONObject jsonObject2 = createJSONObject("2", plants.get(plant2.getSelectedItem().toString()));
        JSONObject jsonObject3 = createJSONObject("3", plants.get(plant3.getSelectedItem().toString()));

        delete("Plantes_humidite/plante_1");
        delete("Plantes_humidite/plante_2");
        delete("Plantes_humidite/plante_3");

        post("Plantes_humidite", jsonObject1);
        post("Plantes_humidite", jsonObject2);
        post("Plantes_humidite", jsonObject3);

        Context context = getApplicationContext();
        CharSequence text = "Sending settings";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();

    }

    public JSONObject createJSONObject(String plant, String value) throws Exception{
        JSONObject jsonObject1 = new JSONObject();
        JSONObject jsonObject2 = new JSONObject();
        JSONObject jsonObject3 = new JSONObject();
        jsonObject1.put("rn", "plante_" + plant);
        jsonObject2.put("cnf", "humidite plante " + plant);
        jsonObject3.put("con", value);

        JSONArray jsonArray = new JSONArray();
        jsonArray.put(jsonObject1);
        jsonArray.put(jsonObject2);
        jsonArray.put(jsonObject3);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("m2m:cin", jsonArray);



        return jsonObject;
    }


    String post(String field, JSONObject jsonObject) {

        HttpURLConnection conn = null;
        String userCredentials = "admin:admin";

        try {

            String newURL = url + field;
            URL _url = new URL(newURL);
            conn = (HttpURLConnection) _url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty(ORIGIN_HEADER, userCredentials);
            conn.setRequestProperty(CT_HEADER, JSON + ";ty=4");
            conn.getOutputStream().write(jsonObject.toString().getBytes());
            conn.connect();
            int resp = conn.getResponseCode();
            if (resp != 200) {

                return null;
            }

        } catch (Exception e) {

            return null;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return null;
    }

    String delete(String field){
        HttpURLConnection conn = null;
        String userCredentials = "admin:admin";

        try {
            String newURL = url + field;
            URL _url = new URL(newURL);
            conn = (HttpURLConnection) _url.openConnection();
            conn.setRequestMethod("DELETE");
            conn.setRequestProperty(ORIGIN_HEADER, userCredentials);
            conn.connect();
            int resp = conn.getResponseCode();
            if (resp != 200) {
                return null;
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return null;
    }

}
