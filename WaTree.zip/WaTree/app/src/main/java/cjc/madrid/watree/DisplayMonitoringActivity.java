package cjc.madrid.watree;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import org.apache.http.HttpConnection;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DisplayMonitoringActivity extends AppCompatActivity {

    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_monitoring_activity);
        StrictMode.setThreadPolicy(policy);

        String temp = retrieve(TEMPERATURE);
        String bri = retrieve(BRIGHTNESS);
        String level = retrieve(TANK_LEVEL);
        TextView textTemperature = (TextView) findViewById(R.id.textViewTemperature);
        TextView textBrightness = (TextView) findViewById(R.id.textViewBrightness);
        TextView textLevel = (TextView) findViewById(R.id.textViewLevel);
        String setTemp = temp + " ºC";
        String setBri = bri + " %";
        String setLevel = level + " %";
        textTemperature.setText(setTemp);
        textBrightness.setText(setBri);
        textLevel.setText(setLevel);
    }

    String url = "http://watreeserveur.ddns.net/~/in-cse/in-name/Watree/";
    private static final String TEMPERATURE = "Temperature/temperature";
    private static final String TANK_LEVEL = "Niveau_eau/niveau_eau";
    private static final String BRIGHTNESS = "Luminosite/luminosite";
    private static final String ORIGIN_HEADER = "X-M2M-Origin";
    private static final String CT_HEADER = "Content-type";
    private static final String ACCEPT = "accept";
    private static final String XML = "application/xml";
    private static final String JSON = "application/json";

    public void f5(View view) throws Exception{
        String temp = retrieve(TEMPERATURE);
        String bri = retrieve(BRIGHTNESS);
        String level = retrieve(TANK_LEVEL);
        TextView textTemperature = (TextView) findViewById(R.id.textViewTemperature);
        TextView textBrightness = (TextView) findViewById(R.id.textViewBrightness);
        TextView textLevel = (TextView) findViewById(R.id.textViewLevel);
        String setTemp = temp + " ºC";
        String setBri = bri + " %";
        String setLevel = level + " %";
        textTemperature.setText(setTemp);
        textBrightness.setText(setBri);
        textLevel.setText(setLevel);
    }


     String retrieve(String field){

        InputStream inputStream = null;
        HttpURLConnection conn = null;
        String userCredentials = "admin:admin";
        //String basicAuth = "Basic" + new String(android.util.Base64.encode(userCredentials.getBytes(),0));

        try{
            String newURL = url + field;
            URL _url = new URL(newURL);
            conn = (HttpURLConnection) _url.openConnection();
            conn.setRequestProperty(ORIGIN_HEADER, userCredentials);
            conn.setRequestMethod("GET");
            conn.setRequestProperty(CT_HEADER, XML);
            conn.connect();
            int resp = conn.getResponseCode();
            if (resp != 200){
                return null;
            }
            inputStream = conn.getInputStream();
            if (inputStream == null){
                return "no InputStream";
            }
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
            BufferedReader reader = new BufferedReader(inputStreamReader);
            StringBuffer buffer = new StringBuffer();
            String line;
            while ((line = reader.readLine()) != null){
                buffer.append(line);
                //buffer.append("/n");
            }
            int first = buffer.indexOf("<con>");
            int last = buffer.lastIndexOf("</con>");
            return (buffer.substring(first+5, last));
        }catch (Exception e){
            return null;
        }finally {
            if (conn != null){
                conn.disconnect();
            }
            if (inputStream != null){
                try {
                    inputStream.close();
                }catch (IOException ignored){

                }
            }
        }


    }

}
